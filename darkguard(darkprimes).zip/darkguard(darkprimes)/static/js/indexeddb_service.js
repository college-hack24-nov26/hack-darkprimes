/**
 * =============================================================================
 * NTRO CYBER THREAT ACTOR INTELLIGENCE - LOCAL INDEXEDDB & STORAGE ENGINE
 * Robust, offline-first client storage for dark web criminal intelligence dossiers.
 * Supports IndexedDB ObjectStores, LocalStorage mirroring, JSON Export/Import,
 * and seamless bidirectional synchronization with the Python Flask backend.
 * =============================================================================
 */

(function (window) {
  'use strict';

  const DB_NAME = 'NTRO_CYBER_INTEL_DB';
  const DB_VERSION = 2;
  const LS_ACTORS_KEY = 'ntro_threat_actors_cache';
  const LS_SYNC_TIME_KEY = 'ntro_last_idb_sync_ts';

  class IndexedDBService {
    constructor() {
      this.db = null;
      this.isReady = false;
      this._initPromise = null;
    }

    /**
     * Initializes the IndexedDB database and schema.
     */
    async init() {
      if (this.isReady && this.db) return this.db;
      if (this._initPromise) return this._initPromise;

      this._initPromise = new Promise((resolve, reject) => {
        if (!window.indexedDB) {
          console.warn('[Storage] IndexedDB not supported in this browser. Falling back strictly to LocalStorage.');
          this.isReady = true;
          this.updateUIStatus();
          resolve(null);
          return;
        }

        const request = window.indexedDB.open(DB_NAME, DB_VERSION);

        request.onupgradeneeded = (event) => {
          const db = event.target.result;
          console.log('[Storage] Upgrading IndexedDB schema to version', DB_VERSION);

          // Threat Actors Store
          if (!db.objectStoreNames.contains('actors')) {
            const actorStore = db.createObjectStore('actors', { keyPath: 'id' });
            actorStore.createIndex('actor_code', 'actor_code', { unique: false });
            actorStore.createIndex('primary_handle', 'primary_handle', { unique: false });
            actorStore.createIndex('category', 'category', { unique: false });
            actorStore.createIndex('risk_score', 'risk_score', { unique: false });
            actorStore.createIndex('status', 'status', { unique: false });
          }

          // Infrastructure Indicators Store
          if (!db.objectStoreNames.contains('indicators')) {
            const indStore = db.createObjectStore('indicators', { keyPath: 'id' });
            indStore.createIndex('indicator_type', 'indicator_type', { unique: false });
            indStore.createIndex('actor_id', 'actor_id', { unique: false });
          }

          // Intelligence Timeline Events Store
          if (!db.objectStoreNames.contains('events')) {
            const evStore = db.createObjectStore('events', { keyPath: 'id' });
            evStore.createIndex('actor_id', 'actor_id', { unique: false });
          }

          // Key-Value Metadata Store
          if (!db.objectStoreNames.contains('meta')) {
            db.createObjectStore('meta', { keyPath: 'key' });
          }
        };

        request.onsuccess = (event) => {
          this.db = event.target.result;
          this.isReady = true;
          console.log('[Storage] IndexedDB connection established successfully.');
          this.updateUIStatus();
          resolve(this.db);
        };

        request.onerror = (event) => {
          console.error('[Storage] IndexedDB open error:', event.target.error);
          this.isReady = true; // Still allow fallback
          resolve(null);
        };
      });

      return this._initPromise;
    }

    /**
     * Retrieves all threat actors / criminals from IndexedDB (or LocalStorage mirror).
     */
    async getAllActors() {
      await this.init();

      if (this.db) {
        try {
          const actors = await new Promise((resolve, reject) => {
            const tx = this.db.transaction(['actors'], 'readonly');
            const store = tx.objectStore('actors');
            const req = store.getAll();
            req.onsuccess = () => resolve(req.result || []);
            req.onerror = () => reject(req.error);
          });

          if (actors && actors.length > 0) {
            // Update local storage backup
            this._saveToLocalStorage(actors);
            return actors;
          }
        } catch (err) {
          console.warn('[Storage] Error reading actors from IndexedDB, trying LocalStorage fallback:', err);
        }
      }

      // Fallback to LocalStorage
      return this._readFromLocalStorage();
    }

    /**
     * Gets a single threat actor by ID or Actor Code.
     */
    async getActorById(idOrCode) {
      if (!idOrCode) return null;
      const all = await this.getAllActors();
      const needle = String(idOrCode).toLowerCase().trim();
      return all.find(a => (
        String(a.id).toLowerCase() === needle ||
        String(a.actor_code).toLowerCase() === needle ||
        String(a.primary_handle || '').toLowerCase() === needle
      )) || null;
    }

    /**
     * Saves or updates a threat actor / criminal record in IndexedDB and LocalStorage mirror.
     */
    async saveActor(actor) {
      await this.init();

      // Ensure mandatory fields
      if (!actor.id) {
        actor.id = 'ta_' + Date.now() + '_' + Math.random().toString(36).substr(2, 6);
      }
      if (!actor.actor_code) {
        actor.actor_code = 'TA-CRIM-' + Math.floor(1000 + Math.random() * 9000);
      }
      if (!actor.first_seen) {
        actor.first_seen = new Date().toISOString();
      }
      if (!actor.last_seen) {
        actor.last_seen = new Date().toISOString();
      }
      actor.is_local_stored = true;
      actor.updated_at = new Date().toISOString();

      if (this.db) {
        try {
          await new Promise((resolve, reject) => {
            const tx = this.db.transaction(['actors'], 'readwrite');
            const store = tx.objectStore('actors');
            const req = store.put(actor);
            req.onsuccess = () => resolve(req.result);
            req.onerror = () => reject(req.error);
          });
        } catch (e) {
          console.error('[Storage] Error saving actor into IndexedDB:', e);
        }
      }

      // Also mirror to LocalStorage
      const localList = this._readFromLocalStorage();
      const idx = localList.findIndex(a => a.id === actor.id || a.actor_code === actor.actor_code);
      if (idx >= 0) {
        localList[idx] = actor;
      } else {
        localList.unshift(actor);
      }
      this._saveToLocalStorage(localList);

      this.notifyUpdate();
      return actor;
    }

    /**
     * Deletes an actor by ID from IndexedDB and LocalStorage.
     */
    async deleteActor(actorId) {
      await this.init();

      if (this.db) {
        try {
          await new Promise((resolve, reject) => {
            const tx = this.db.transaction(['actors'], 'readwrite');
            const store = tx.objectStore('actors');
            const req = store.delete(actorId);
            req.onsuccess = () => resolve();
            req.onerror = () => reject(req.error);
          });
        } catch (e) {
          console.warn('[Storage] Error deleting from IndexedDB:', e);
        }
      }

      const list = this._readFromLocalStorage().filter(a => a.id !== actorId && a.actor_code !== actorId);
      this._saveToLocalStorage(list);

      this.notifyUpdate();
      return true;
    }

    /**
     * Synchronizes IndexedDB with the backend server (/api/actors).
     * Bidirectional: Pulls any new records from server and pushes local manual additions.
     */
    async syncWithServer() {
      try {
        console.log('[Storage] Synchronizing local IndexedDB with Flask server...');
        const res = await fetch('/api/actors');
        const json = await res.json();
        
        if (json.status !== 'success' || !Array.isArray(json.data)) {
          throw new Error('Invalid response from server actors API');
        }

        const serverActors = json.data;
        const localActors = await this.getAllActors();

        // Find locally created actors that may not exist on server
        const unsyncedLocals = localActors.filter(la => 
          la.is_manual && !serverActors.some(sa => sa.id === la.id || sa.actor_code === la.actor_code)
        );

        if (unsyncedLocals.length > 0) {
          console.log(`[Storage] Uploading ${unsyncedLocals.length} local criminal records to server...`);
          await fetch('/api/sync/actors', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ actors: unsyncedLocals })
          });
        }

        // Store all combined records into IndexedDB
        const actorMap = new Map();
        // Server actors first
        for (const sa of serverActors) {
          actorMap.set(sa.id, sa);
        }
        // Local actors overlay
        for (const la of localActors) {
          actorMap.set(la.id, { ...(actorMap.get(la.id) || {}), ...la });
        }

        const mergedActors = Array.from(actorMap.values());

        // Batch write to IndexedDB
        if (this.db) {
          const tx = this.db.transaction(['actors'], 'readwrite');
          const store = tx.objectStore('actors');
          for (const a of mergedActors) {
            store.put(a);
          }
          await new Promise((resolve) => {
            tx.oncomplete = () => resolve();
            tx.onerror = () => resolve();
          });
        }

        this._saveToLocalStorage(mergedActors);
        localStorage.setItem(LS_SYNC_TIME_KEY, new Date().toISOString());

        this.notifyUpdate();
        console.log(`[Storage] Sync complete. Total active criminal profiles: ${mergedActors.length}`);
        return { success: true, count: mergedActors.length };
      } catch (err) {
        console.error('[Storage] Sync failed:', err);
        return { success: false, error: err.message };
      }
    }

    /**
     * Exports all local IndexedDB records as a downloadable JSON file.
     */
    async exportToJSON() {
      const actors = await this.getAllActors();
      const exportPayload = {
        title: 'NTRO Threat Actor & Criminal Intelligence Database Export',
        exported_at: new Date().toISOString(),
        version: '2.0-IndexedDB',
        count: actors.length,
        classification: 'RESTRICTED // SOC LOCAL INTEL',
        actors: actors
      };

      const dataStr = 'data:text/json;charset=utf-8,' + encodeURIComponent(JSON.stringify(exportPayload, null, 2));
      const downloadAnchor = document.createElement('a');
      downloadAnchor.setAttribute('href', dataStr);
      downloadAnchor.setAttribute('download', `ntro_criminal_intelligence_indexeddb_${Date.now()}.json`);
      document.body.appendChild(downloadAnchor);
      downloadAnchor.click();
      downloadAnchor.remove();

      return true;
    }

    /**
     * Imports criminal intelligence records from a JSON file.
     */
    async importFromJSON(jsonString) {
      try {
        const parsed = typeof jsonString === 'string' ? JSON.parse(jsonString) : jsonString;
        const incoming = Array.isArray(parsed) ? parsed : (parsed.actors || parsed.data || []);
        if (!Array.isArray(incoming) || incoming.length === 0) {
          throw new Error('No valid threat actor records found in the import payload.');
        }

        let imported = 0;
        for (const item of incoming) {
          if (item && (item.primary_handle || item.actor_code)) {
            await this.saveActor(item);
            imported++;
          }
        }

        this.notifyUpdate();
        return { success: true, importedCount: imported };
      } catch (e) {
        return { success: false, error: e.message };
      }
    }

    /**
     * Clears all threat actors from local IndexedDB & LocalStorage.
     */
    async clearLocalDB() {
      await this.init();
      if (this.db) {
        try {
          const tx = this.db.transaction(['actors'], 'readwrite');
          tx.objectStore('actors').clear();
          await new Promise(res => { tx.oncomplete = res; });
        } catch (e) {
          console.warn('[Storage] Clear IndexedDB warning:', e);
        }
      }
      localStorage.removeItem(LS_ACTORS_KEY);
      this.notifyUpdate();
      return true;
    }

    /**
     * Returns live storage statistics.
     */
    async getStats() {
      const actors = await this.getAllActors();
      const lastSync = localStorage.getItem(LS_SYNC_TIME_KEY) || 'Never synced';
      return {
        totalRecords: actors.length,
        engine: this.db ? 'IndexedDB (Active) + LocalStorage Mirror' : 'LocalStorage Cache',
        databaseName: DB_NAME,
        version: DB_VERSION,
        lastSync: lastSync
      };
    }

    notifyUpdate() {
      this.updateUIStatus();
      window.dispatchEvent(new CustomEvent('ntro:storage-updated'));
    }

    async updateUIStatus() {
      try {
        const stats = await this.getStats();
        const countElements = document.querySelectorAll('.idb-records-counter, #idb-actor-count, #idb-count');
        countElements.forEach(el => {
          el.innerText = stats.totalRecords;
        });

        const statusPills = document.querySelectorAll('#storage-status-text');
        statusPills.forEach(el => {
          el.innerText = `IndexedDB: ${stats.totalRecords} Recs`;
        });
      } catch (e) {
        // Silent
      }
    }

    _readFromLocalStorage() {
      try {
        const data = localStorage.getItem(LS_ACTORS_KEY);
        return data ? JSON.parse(data) : [];
      } catch (e) {
        return [];
      }
    }

    _saveToLocalStorage(actors) {
      try {
        localStorage.setItem(LS_ACTORS_KEY, JSON.stringify(actors));
      } catch (e) {
        // Quota exceeded safe handling
      }
    }
  }

  // Expose global singleton instance
  window.cyberStorage = new IndexedDBService();

  // Auto-init on page load and trigger server sync if local is empty
  document.addEventListener('DOMContentLoaded', async () => {
    try {
      await window.cyberStorage.init();
      const existing = await window.cyberStorage.getAllActors();
      if (existing.length === 0) {
        console.log('[Storage] Local storage empty on startup. Triggering initial seed sync from server...');
        await window.cyberStorage.syncWithServer();
      } else {
        window.cyberStorage.updateUIStatus();
      }
    } catch (e) {
      console.warn('[Storage] Auto-init warning:', e);
    }
  });

})(window);
