# NTRO Dark Web Threat Actor De-Anonymization & Attribution Intelligence Platform

[![Python](https://img.shields.io/badge/Python-3.10%2B-blue.svg)](https://www.python.org/)
[![Flask](https://img.shields.io/badge/Framework-Flask%203.0-lightgrey.svg)](https://flask.palletsprojects.com/)
[![Database](https://img.shields.io/badge/Database-Supabase%20PostgreSQL-green.svg)](https://supabase.com/)
[![Theme](https://img.shields.io/badge/Theme-Blockchain%20%26%20Cybersecurity-red.svg)](#)
[![Status](https://img.shields.io/badge/Status-Hackathon%20Ready-brightgreen.svg)](#)

> **PROBLEM STATEMENT ID:** 26151  
> **ORGANIZATION:** National Technical Research Organisation (NTRO)  
> **THEME:** Blockchain & Cybersecurity  
> **CLASSIFICATION:** Defensive Cybersecurity Intelligence Platform (Probabilistic Attribution)

---

## 1. Project Overview & Objective

The **NTRO Dark Web Threat Actor De-Anonymization and Attribution Intelligence Analysis Platform** is an enterprise-grade cybersecurity intelligence system designed for defensive analysts and national security researchers. 

It provides an end-to-end analytical pipeline to **collect, contextualize, correlate, and query threat-intelligence data** spanning darknet forums, cryptocurrency ledgers, PGP keyrings, and passive infrastructure indicators. All attribution insights are computed as **probabilistic mathematical correlations** rather than unverified identity claims, upholding strict defensive ethics.

---

## 2. Defensive Cybersecurity Safeguards

> [!IMPORTANT]
> **DEFENSIVE COMPLIANCE & SAFETY NOTICE**
> - **No Active Exploitation:** The platform performs zero credential theft, active vulnerability exploitation, unauthorized system access, or Tor network traffic correlation attacks.
> - **Passive & Open Indicators:** Evaluates passive DNS history, Certificate Transparency logs, JA3 TLS hashes, and public darknet forum discussion metadata.
> - **Synthetic Demonstration Dataset:** Preloaded with fictional actor entities (`NIGHTFALCON`, `SHADOWBYTE`, `DARKORBIT`, `CRYPTONOVA`, `VOIDWALKER`, `SPECTRE_GHOST`, `ASTRAL_PHANTOM`, etc.) and mock blockchain wallets to protect operational privacy.
> - **Probabilistic Attribution:** All outputs clearly convey analytical confidence percentages and evidentiary justifications.

---

## 3. Key Capabilities & Analytical Modules

1. **Executive SOC Command Dashboard**: Real-time KPI telemetry, risk distributions, temporal campaign trajectory charts, and highest-risk threat feeds.
2. **Threat Actor Directory**: Searchable, filterable repository of monitored threat clusters with sortable risk tiers, primary handles, and quick action drawers.
3. **11-Tab Deep Dossier**: Complete intelligence packaging across *Overview, Handles, PGP Keys, Wallets, Marketplaces, Infrastructure, Persona, Relationships, Timeline, Evidence, and Sources*.
4. **Interactive Cytoscape.js Relationship Graph**: Force-directed topological network visualization linking threat actors, aliases, PGP fingerprints, cryptocurrency wallets, marketplaces, and infrastructure nodes with click-to-inspect evidence drawer.
5. **Defensive Persona Stylometry Engine (`persona_engine.py`)**: Multi-dimensional Scikit-Learn TF-IDF, N-gram stylometry, Type-Token Ratio (TTR), vocabulary entropy, and operational cadence matching.
6. **4-Pillar Quantitative Risk Engine (`risk_engine.py`)**: Real-time mathematical scoring combining Infrastructure, Behavioural, Network, and Activity risk with automated mitigation recommendations.
7. **Temporal Intelligence Timeline**: Chronological event tracking from first observed forum registration to cryptocurrency transactions and zero-day exploit auctions.
8. **Passive Infrastructure Radar**: Monitoring of Tor v3 hidden services, JA3 fingerprints, SSH banners, and bulletproof ASN colocation.
9. **Automated Export & Printable PDF Dossier**: Instant download in structured CSV, JSON intelligence packages, and print-optimized PDF briefings.
10. **Dual Database Architecture**: Seamless live Supabase PostgreSQL connection with instant graceful fallback to high-fidelity in-memory demonstration mode.

---

## 4. Technology Stack

- **Backend**: Python 3.10+, Flask 3.0, RESTful Blueprint Architecture
- **Database**: Supabase PostgreSQL (UUID primary keys, foreign keys, performance indexes) + Python `supabase` SDK
- **Analytical Engines**: Scikit-learn (TF-IDF Vectorizer, Cosine Similarity), NumPy, Pandas, NetworkX
- **Frontend**: HTML5, Vanilla CSS3 (Custom Dark SOC Cyber Design System, Glassmorphism, Neon Glow Accents), Vanilla JavaScript ES6+
- **Visualizations**: Cytoscape.js (Force-directed Graph Topology), Chart.js (Doughnut, Line, Horizontal Bar, Radar, Pie)
- **Icons & Typography**: FontAwesome 6.4, Inter, JetBrains Mono
- **Testing**: Pytest automated test suite

---

## 5. Directory Structure

```
sih project/
├── app.py                      # Flask application factory, routes & startup banner
├── config.py                   # Environment & Supabase credentials loader
├── requirements.txt            # Python dependencies
├── schema.sql                  # PostgreSQL DDL with indexes & constraints
├── seed.sql                    # SQL seed script for Supabase SQL Editor
├── .env.example                # Configuration template
├── README.md                   # Complete documentation & demo walkthrough
│
├── core/
│   ├── __init__.py
│   ├── database.py             # Supabase client with graceful offline fallback
│   ├── seed_data.py            # High-fidelity synthetic dataset (12 actors, 27 handles, 16 wallets, etc.)
│   ├── persona_engine.py       # Scikit-learn TF-IDF & stylometric similarity engine
│   └── risk_engine.py          # 4-factor risk assessment model & mitigation generator
│
├── routes/
│   ├── __init__.py
│   ├── api.py                  # All REST API endpoints (/api/dashboard/stats, /api/actors, etc.)
│   ├── export.py               # CSV, JSON, and printable HTML/PDF dossier handlers
│   └── views.py                # Web page controllers for all 11 pages
│
├── templates/
│   ├── base.html               # Master SOC shell with topbar, glass sidebar & alerts
│   ├── dashboard.html          # Executive SOC Overview
│   ├── actors.html             # Threat Actor Directory
│   ├── actor_detail.html       # 11-Tab Deep Dossier
│   ├── infrastructure.html     # Passive Infrastructure Telemetry
│   ├── relationships.html      # Interactive Cytoscape.js Relationship Graph
│   ├── persona.html            # Stylometric Persona Matcher with Radar Chart
│   ├── timeline.html           # Temporal Attack Trail & Events Feed
│   ├── sources.html            # Intelligence Source Provenance
│   ├── risk.html               # 4-Factor Risk Matrix Simulator
│   ├── reports.html            # Executive Threat Dossier Generator
│   ├── settings.html           # System Diagnostics & Demo Reset
│   └── report_print.html       # Print-ready Official Intelligence Dossier
│
├── static/
│   ├── css/
│   │   └── style.css           # Premium Dark SOC design system & animations
│   └── js/
│       ├── main.js             # Global utilities, toast system & search
│       ├── dashboard.js        # Real-time Chart.js KPI analytics
│       ├── actors.js           # Filtering, search & actor table
│       ├── actor_detail.js     # 11-tab asynchronous dossier loader
│       ├── graph.js            # Cytoscape.js network visualizer & inspector
│       ├── persona.js          # Stylometric comparison & radar visualizer
│       ├── timeline.js         # Chronological event explorer
│       ├── risk.js             # Interactive risk recalculation
│       └── reports.js          # Dossier preview & export dispatcher
│
└── tests/
    ├── __init__.py
    ├── test_api.py             # REST API endpoint tests
    ├── test_persona_engine.py  # Stylometry and TF-IDF similarity tests
    └── test_risk_engine.py     # 4-factor risk calculation tests
```

---

## 6. Windows Setup & Installation Guide

Follow these exact steps in **PowerShell** or **Command Prompt**:

### Step 1: Create Virtual Environment
```powershell
python -m venv venv
```

### Step 2: Activate Virtual Environment
```powershell
venv\Scripts\activate
```

### Step 3: Install Required Dependencies
```powershell
pip install -r requirements.txt
```

### Step 4: Configure Supabase (Optional)
The system runs immediately out of the box in **Synthetic In-Memory Mode**. If you want to connect a live Supabase PostgreSQL database:

1. Copy `.env.example` to `.env`:
   ```powershell
   copy .env.example .env
   ```
2. Edit `.env` and set:
   ```ini
   SUPABASE_URL=https://your-project-id.supabase.co
   SUPABASE_KEY=your-supabase-anon-or-publishable-key
   SECRET_KEY=cyber-soc-ntro-secret-key-2026
   ```
3. Open your [Supabase SQL Editor](https://supabase.com/dashboard/project/_/sql) and run [schema.sql](file:///c:/Users/HP/Desktop/sih%20project/schema.sql) followed by [seed.sql](file:///c:/Users/HP/Desktop/sih%20project/seed.sql).

### Step 5: Start the Platform
```powershell
python app.py
```

Open your browser and navigate to:
```
http://127.0.0.1:5000
```

---

## 7. Running Automated Test Suite

Run `pytest` to validate all API endpoints, risk calculations, and stylometric NLP models:

```powershell
pytest
```

---

## 8. REST API Reference

| Method | Endpoint | Description |
| :--- | :--- | :--- |
| `GET` | `/api/dashboard/stats` | Executive KPI counts, risk distributions, and category breakdowns |
| `GET` | `/api/actors` | Filtered list of threat actors (`search`, `risk`, `category`, `status`) |
| `GET` | `/api/actors/<actor_id>` | Specific threat actor profile |
| `GET` | `/api/actors/<actor_id>/handles` | Observed aliases and forum accounts |
| `GET` | `/api/actors/<actor_id>/pgp` | Cryptographic PGP public keys and fingerprints |
| `GET` | `/api/actors/<actor_id>/wallets` | Cryptocurrency wallets, USD totals, and risk levels |
| `GET` | `/api/actors/<actor_id>/marketplaces` | Underground forum/marketplace memberships and sales |
| `GET` | `/api/actors/<actor_id>/infrastructure` | Passive TLS, JA3, DNS, and IP indicators |
| `GET` | `/api/actors/<actor_id>/relationships` | Direct topological network connections |
| `GET` | `/api/graph/data` | Complete Cytoscape.js nodes and edges dataset |
| `GET` | `/api/persona-links` | Pairwise stylometric and behavioral similarity links |
| `POST` | `/api/persona/analyze` | Computes live TF-IDF and stylometric similarity between two actors/texts |
| `GET` | `/api/infrastructure` | Passive infrastructure observables (`search`, `type`) |
| `GET` | `/api/intelligence-events` | Chronological intelligence events (`actor_id`, `limit`) |
| `GET` | `/api/sources` | Ingestion pipelines, reliability scores, and provenance |
| `GET` | `/api/risk/<actor_id>` | Baseline 4-factor risk assessment |
| `POST` | `/api/risk/calculate` | Calculates weighted composite risk from custom parameters |
| `GET` | `/api/export/actor/<actor_id>/json` | Downloads full JSON intelligence package |
| `GET` | `/api/export/actor/<actor_id>/csv` | Downloads structured CSV summary |
| `GET` | `/api/report/actor/<actor_id>` | Renders print-ready HTML/PDF intelligence dossier |
| `POST` | `/api/system/reset-demo` | Resets the in-memory dataset |

---

## 9. Hackathon Jury Demonstration Script (5-Minute Walkthrough)

To deliver an exceptional presentation during the hackathon evaluation, follow this structured demonstration flow:

1. **Dashboard Overview (0:00 - 1:00)**:
   - Point out the **SOC Command Center styling**, dark cybersecurity glassmorphism cards, glowing neon accents, and live KPI feeds.
   - Explain how passive darknet feeds are aggregated into real-time risk tiers (Critical, High, Medium, Low) and category distributions.
   - Highlight the **Defensive Compliance Ribbon** emphasizing probabilistic attribution and synthetic testing data.

2. **Threat Actor Dossier Investigation (1:00 - 2:00)**:
   - Navigate to **Threat Actors** (`/actors`), demonstrating dynamic search and multi-criteria filters.
   - Click **Dossier** on `TA-NIGHTFALCON-01`.
   - Walk through the **11-tab intelligence layout**: showing forum aliases across Dread/Exploit, 4096-bit RSA PGP fingerprints, Monero/BTC wallet clusters with transaction volumes, and passive infrastructure nodes.

3. **Interactive Relationship Graph (2:00 - 3:00)**:
   - Navigate to **Relationship Graph** (`/relationships`).
   - Demonstrate **interactive physics**, zoom/pan controls, and click on nodes/edges.
   - Show how clicking any node (e.g. `NightFalcon` or `0x55BFE790...`) opens the **Evidence Inspector Drawer**, revealing attribution confidence and multi-source corroboration.

4. **Persona Stylometry & NLP Similarity Engine (3:00 - 4:00)**:
   - Navigate to **Persona Analysis** (`/persona`).
   - Select `NightFalcon` (Subject A) and `ShadowByte` (Subject B).
   - Click **Execute Stylometric & Persona Analysis**.
   - Show the **Scikit-Learn TF-IDF Cosine Similarity** and **Type-Token Ratio (TTR)** radar chart (87.6% match), highlighting shared phrasing (`"guaranteed clean domain admin"`, `"work through escrow only"`).
   - Explain how this provides defensible probabilistic attribution for analysts.

5. **Risk Calculator & Dossier PDF Export (4:00 - 5:00)**:
   - Navigate to **Risk Analysis** (`/risk`) and adjust the 4 factor sliders in real time to show dynamic tier shifts and automated defensive mitigation suggestions.
   - Navigate to **Reports** (`/reports`) and click **Generate Printable Dossier (PDF)** to showcase the unredacted official intelligence report ready for executive briefing.

---

## 10. Future Scope & Roadmap

- **Graph Neural Networks (GNNs)**: Integration of PyTorch Geometric for automated link prediction on darknet escrow graphs.
- **Automated STIX 2.1 / TAXII Feeds**: Real-time push and subscription endpoints for national SOC interoperability.
- **Zero-Knowledge Multi-Party Computation**: Secure cross-agency indicator sharing without exposing sensitive watchlists.

---

## 11. Author & Acknowledgments

- **Problem Statement:** 26151 — Dark Web Threat Actor De-anonymization
- **Organization:** National Technical Research Organisation (NTRO)
- **Built for:** Smart India Hackathon (SIH) 2026
